## Metadane

Orginalna baza danych jest dostępna pod scieżką: ../Original Data/tb.csv

Kolumny które koduje baza tb.csv to kolejno:
indeks, kraj, rok, liczba wystąpnień jednostek chorobwych w określonym przedziale wiekowym dla mężczyzn, liczba wystąpnień jednostek chorobwych w określonym przedziale wiekowym dla kobiet.

Tabela zawiera 24 kolumny oraz 5768 rekordów
